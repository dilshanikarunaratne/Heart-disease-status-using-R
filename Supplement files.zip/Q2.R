
myFunc <- function(input_df, response_var){
  
  #Assign the input data frame into a new data frame
  new_df <- input_df
  #Reset the all variable names 
  new_df_var_type <- c(0)
  new_df_var_name <- c(0)
  new_df_mean <- c(0)
  new_df_median <- c(0)
  new_df_distinct <- c(0)
  new_df_mode <- c(0)
  new_df_na <- c(0)
  new_df_out <- list()
  #dividing the canvas to get better plots
  par(mfrow = c(3,3))
  

  
  #looping through all the columns
  for (column in 1:length(new_df)) {
    
    #sorting out the quantitative variables
    if(is.numeric(new_df[[column]]))
    {
      #declare the quantitative variables as "Quantitative"
      new_df_var_type[column] <- "Quantitative"
      #quantitative column name list
      new_df_var_name[column] <- names(new_df[column])
      #mean of those columns ignoring all the missing values
      new_df_mean[column] <- mean(new_df[[column]], na.rm = T)
      #median of those columns ignoring all the missing values
      new_df_median[column] <- median(new_df[[column]], na.rm = T)
      #mode of the column
      new_df_distinct <- levels(factor(new_df[[column]]))
      new_df_mode[column] <- new_df_distinct[which.max(tabulate(match(new_df[[column]], new_df_distinct)))]
      #counting the number of missing values
      new_df_na[column] <- sum(is.na(new_df[[column]]))
      #imputation with mean
      new_df[which(is.na(new_df[[column]])), column] <- new_df_mean[column]
      #find the outliers of the data set
      new_df_out[[column]] <- boxplot.stats(new_df[[column]])$out
      #drawing boxplots
      boxplot(new_df[[column]], new = "Boxplot", col = c("violetred2", "forestgreen" , "deeppink2"), main = paste("Boxplot of",new_df_var_name[column]))
      #drawing histograms
      hist(new_df[[column]], new = "Histogram", col = c("red3", "navyblue" , "yellow3", "forestgreen"),main = paste("Histogram of",new_df_var_name[column]), xlab = new_df_var_name[column])
    }
    
    
    
    #sorting out the qualitative variables
    else{
      
      #declare the qualitative variables as "Qualitative"
      new_df_var_type[column] <- "Qualitative"
      #quantitative column name list
      new_df_var_name[column] <- names(new_df[column])
      #For qualitative variables, there are no mean, median or outliers present. Therefore,
      new_df_mean <- c(0)
      new_df_median <- c(0)
      new_df_out <- c(0)
      #mode of the column
      new_df_distinct <- levels(factor(new_df[[column]]))
      new_df_mode[column] <- new_df_distinct[which.max(tabulate(match(new_df[[column]], new_df_distinct)))]
      #counting the number of missing values
      new_df_na[column] <- sum(is.na(new_df[[column]]))
      #mode imputation
      new_df[which(is.na(new_df[[column]])), column] <- new_df_mode[column]
      #drawing barplots
      barplot(table(new_df[[column]]), ylab = "Frequency", new = "Bar chart", border="black", col="grey")
    }
    
  }
  
  
  names(new_df_out) <- names(new_df)
  
  #get the summary of the dataset
  new_df_summary <- data.frame(column_name = new_df_var_name, variable_type = new_df_var_type, 
                                mean = new_df_mean, median = new_df_median, mode = new_df_mode, 
                                count_of_missing_values = new_df_na)
  
  #printing the summary of new datasets with qualitative/quantitative variables
  print(new_df_summary)
  print(new_df_out)
  
  #implementing best predictive model
  res <- response_var
  new_df_res <- grep(res, colnames(new_df))
  
  if(is.numeric(new_df[,new_df_res]))
  {
    num <- unlist(lapply(new_df, is.numeric))
    new_df_pred <- new_df[,num]
    
    new_df_index <- match(res,names(new_df_pred)) 
    new_df_input <- new_df_pred[-new_df_index]
    new_df_target <- c()
    
    for (ind in new_df_pred[new_df_index]){
      new_df_target <- ind
    }
    
    new_df_mdl_full <- lm(new_df_target ~ ., data = new_df_input)
    new_df_mdl_bk <- step(new_df_mdl_full, direction = "backward")
    
    new_df_mdl_pred <- predict.lm(new_df_mdl_bk, newdata = new_df_input)
    
    new_df_pred_data <- cbind(new_df_target, new_df_mdl_pred)
    new_df_pred_data
    
    summary(new_df_mdl_bk)
    new_df_mdl_bk$coefficients
  }
  else {
    print("Response variable of the dataset is a categorical variable.")
  }
}

myFunc(mtcars)

